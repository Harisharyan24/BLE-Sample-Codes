#ifndef CUSTOM_SERVICE_H_
#define CUSTOM_SERVICE_H_

#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/conn.h>
extern struct bt_conn *current_conn;
extern struct k_work_delayable notify_work;
extern  struct k_work_delayable indicate_work_char4;

void custom_notify_all(void);
void custom_indicate_all(void);
// void custom_service_init(void);
#endif /* CUSTOM_SERVICE_H_ */