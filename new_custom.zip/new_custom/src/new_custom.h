// #ifndef CUSTOM_SERVICE_H_
// #define CUSTOM_SERVICE_H_

// #include <zephyr/bluetooth/services/hrs.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>


#define BT_UUID_CUSTOM_SERVICE_VAL \
    BT_UUID_128_ENCODE(0x12345678, 0x1234, 0x5678, 0x1234, 0x56789abcdef0)

//bool cus_ntf_enabled; //remember 
extern uint8_t cus_ntf_enabled;
extern uint8_t cus_ind_enabled;
// #include <zephyr/bluetooth/conn.h>
extern struct bt_conn *current_conn;
extern struct k_work_delayable notify_work;
extern  struct k_work_delayable indicate_work_char4;

void custom_notify_all(void);
void custom_indicate_all(void);
// void custom_service_init(void);
// #endif /* CUSTOM_SERVICE_H_ */